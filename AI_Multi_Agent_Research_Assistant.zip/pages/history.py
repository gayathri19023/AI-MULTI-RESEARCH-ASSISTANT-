"""Native route forwarding to the complete research-history view in app.py."""
import streamlit as st

st.session_state["nav_page"] = "Research History"
st.switch_page("app.py")
