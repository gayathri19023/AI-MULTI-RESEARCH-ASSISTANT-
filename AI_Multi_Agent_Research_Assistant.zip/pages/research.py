"""Native route forwarding to the complete new-research view in app.py."""
import streamlit as st

st.session_state["nav_page"] = "New Research"
st.switch_page("app.py")
