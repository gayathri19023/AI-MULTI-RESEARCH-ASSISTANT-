"""Native route forwarding to the complete document-analysis view in app.py."""
import streamlit as st

st.session_state["nav_page"] = "Document Analysis"
st.switch_page("app.py")
