"""Page modules are represented by navigation routes in app.py for a compact deployment."""
