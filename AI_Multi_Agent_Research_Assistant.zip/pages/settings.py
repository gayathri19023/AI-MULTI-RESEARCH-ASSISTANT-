"""Native route forwarding to the complete settings view in app.py."""
import streamlit as st

st.session_state["nav_page"] = "Settings"
st.switch_page("app.py")
