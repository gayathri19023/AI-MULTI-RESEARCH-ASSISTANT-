"""Native Streamlit Dashboard route.

This file must render content itself because Streamlit maps /dashboard directly
to it when the pages directory is present.
"""
import pandas as pd
import plotly.express as px
import streamlit as st

from services.dashboard_service import get_dashboard_data


def render_dashboard() -> None:
    """Render a useful dashboard for both empty and populated databases."""
    st.title("AI Multi-Agent Research Assistant")
    st.subheader("One Question. Multiple AI Agents. One Research Report.")
    st.write(
        "Track research activity, evidence collection, claim checking, and potential research gaps."
    )
    data = get_dashboard_data()
    if data["error"]:
        st.warning(data["error"])

    metrics = data["metrics"]
    cards = st.columns(5)
    cards[0].metric("Total Research Sessions", metrics["sessions"])
    cards[1].metric("Total Sources", metrics["sources"])
    cards[2].metric("Academic Papers", metrics["academic"])
    cards[3].metric("Claims Checked", metrics["claims"])
    cards[4].metric("Potential Research Gaps", metrics["gaps"])

    st.subheader("Recent Research")
    if data["recent"]:
        st.dataframe(pd.DataFrame(data["recent"]), use_container_width=True, hide_index=True)
    else:
        st.info("No research sessions yet. Open New Research in the sidebar to start your first analysis.")

    st.subheader("Research Activity")
    if data["activity"]:
        activity = pd.DataFrame(data["activity"])
        chart = px.bar(activity, x="Date", y="Research Sessions", title="Research sessions by date")
        st.plotly_chart(chart, use_container_width=True)
    else:
        st.caption("Activity statistics will appear after research sessions are saved.")


if __name__ == "__main__":
    st.set_page_config(page_title="Dashboard | AI Research Assistant", page_icon="🔬", layout="wide")
    render_dashboard()
