from services.dashboard_service import get_dashboard_data


def test_dashboard_handles_an_empty_database() -> None:
    data = get_dashboard_data()
    assert set(data["metrics"]) == {"sessions", "sources", "academic", "claims", "gaps"}
    assert all(isinstance(value, int) for value in data["metrics"].values())
    assert isinstance(data["recent"], list)
    assert isinstance(data["activity"], list)
