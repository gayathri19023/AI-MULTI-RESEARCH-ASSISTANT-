from database import init_db
from services.citation_service import citation
from services.document_parser import extract_document
from services.report_generator import make_docx, make_pdf
from workflows import run_research

def test_database_initializes(): init_db()
def test_document_extraction(): assert "hello" in extract_document("note.txt",b"hello research")["text"]
def test_citation_has_real_fields(): assert "Example" in citation({"title":"Example","authors":"A. Author","year":"2024","url":"https://example.org"},"APA")
def test_demo_workflow_and_exports():
    state=run_research("How does AI affect education?",demo=True)
    assert state["sources"] and state["citations"]
    assert make_pdf(state).startswith(b"%PDF")
    assert make_docx(state).startswith(b"PK")
def test_claim_statuses_are_valid():
    state=run_research("AI in education",demo=True)
    assert all(c["status"] in {"Supported","Partially Supported","Conflicting Evidence","Not Sufficiently Verified"} for c in state["claims"])
