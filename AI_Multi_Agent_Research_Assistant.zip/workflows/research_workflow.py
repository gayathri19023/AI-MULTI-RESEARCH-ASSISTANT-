"""LangGraph workflow coordinating specialized research agents."""
from typing import TypedDict, Any
from langgraph.graph import StateGraph, END
from agents.research_manager import research_manager
from agents.web_research_agent import web_research
from agents.academic_research_agent import academic_research
from agents.document_analysis_agent import document_analysis
from agents.data_analysis_agent import data_analysis
from agents.comparison_agent import compare_sources
from agents.fact_checker_agent import fact_check
from agents.research_gap_agent import research_gaps
from agents.citation_agent import citation_agent
from agents.report_writer_agent import report_writer

class ResearchState(TypedDict, total=False):
    question: str; topic: str; demo: bool; source_limit: int; citation_style: str; documents: list; sources: list; warnings: list; agent_results: dict; findings: list; comparison: list; claims: list; gaps: list; citations: list; summary: str; report: str

def build_workflow():
    graph = StateGraph(ResearchState)
    for name, func in [("manager",research_manager),("web",web_research),("academic",academic_research),("documents",document_analysis),("data",data_analysis),("comparison",compare_sources),("fact_check",fact_check),("gaps",research_gaps),("citations",citation_agent),("report",report_writer)]: graph.add_node(name, func)
    graph.set_entry_point("manager")
    for a,b in zip(["manager","web","academic","documents","data","comparison","fact_check","gaps","citations"],["web","academic","documents","data","comparison","fact_check","gaps","citations","report"]): graph.add_edge(a,b)
    graph.add_edge("report", END)
    return graph.compile()

WORKFLOW = build_workflow()
def run_research(question: str, *, demo: bool=True, source_limit: int=5, citation_style: str="APA", documents: list[dict] | None=None) -> dict:
    if not question.strip(): raise ValueError("Enter a research question before starting.")
    return dict(WORKFLOW.invoke({"question": question.strip(), "demo": demo, "source_limit": source_limit, "citation_style": citation_style, "documents": documents or [], "sources": [], "warnings": [], "agent_results": {}, "findings": []}))
