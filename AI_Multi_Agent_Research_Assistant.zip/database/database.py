"""Database setup and persistence helpers."""
from contextlib import contextmanager
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from config import DATABASE_URL
from database.models import Base, ResearchSession, Source, Document, AgentResult, Claim, ResearchGap, Report

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)

def init_db() -> None:
    Base.metadata.create_all(engine)

@contextmanager
def get_session():
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def save_research(state: dict) -> int:
    with get_session() as db:
        item = ResearchSession(topic=state["topic"], question=state["question"], status="completed", summary=state.get("summary", ""))
        db.add(item); db.flush()
        for source in state.get("sources", []):
            db.add(Source(session_id=item.id, title=source.get("title", "Untitled"), url=source.get("url", ""), source_type=source.get("type", "web"), year=str(source.get("year", "")), authors=source.get("authors", ""), abstract=source.get("abstract", source.get("snippet", ""))))
        for document in state.get("documents", []):
            db.add(Document(session_id=item.id, filename=document.get("filename", "untitled"), file_type=document.get("type", ""), pages=int(document.get("pages", 0)), extracted_text=document.get("text", "")))
        for name, result in state.get("agent_results", {}).items(): db.add(AgentResult(session_id=item.id, agent_name=name, result=str(result)))
        for claim in state.get("claims", []): db.add(Claim(session_id=item.id, claim_text=claim["claim"], status=claim["status"], evidence=claim.get("evidence", "")))
        for gap in state.get("gaps", []): db.add(ResearchGap(session_id=item.id, gap_text=gap["gap"], future_topic=gap.get("future", "")))
        db.add(Report(session_id=item.id, content=state.get("report", "")))
        return item.id
