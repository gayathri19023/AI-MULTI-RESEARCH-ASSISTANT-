"""Small, explicitly labelled local dataset used only in demo mode."""
DEMO_SOURCES = [
 {"title":"Artificial Intelligence and the Future of Teaching and Learning","url":"https://www.oecd.org/en/publications/artificial-intelligence-and-the-future-of-teaching-and-learning_07e1f0da-en.html","type":"web","year":"2021","authors":"OECD","snippet":"Policy analysis of AI opportunities and risks for education."},
 {"title":"Guidance for generative AI in education and research","url":"https://unesdoc.unesco.org/ark:/48223/pf0000386693","type":"web","year":"2023","authors":"UNESCO","snippet":"Guidance addressing human agency, privacy, equity and validation."},
 {"title":"The impact of artificial intelligence on learning, teaching, and education","url":"https://publications.jrc.ec.europa.eu/repository/handle/JRC113226","type":"academic","year":"2018","authors":"Tuomi, I.","abstract":"Review of AI applications and their potential impact on education."},
]
