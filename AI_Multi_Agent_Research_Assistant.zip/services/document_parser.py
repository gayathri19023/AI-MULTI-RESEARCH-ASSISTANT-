"""Safe text extraction for the supported user-uploaded document formats."""
from io import BytesIO
from pypdf import PdfReader
from docx import Document

def extract_document(name: str, content: bytes) -> dict:
    suffix = name.rsplit(".", 1)[-1].lower()
    if suffix == "txt":
        text = content.decode("utf-8", errors="replace")
        return {"filename": name, "type": "TXT", "pages": 1, "text": text}
    if suffix == "pdf":
        reader = PdfReader(BytesIO(content)); text = "\n".join(page.extract_text() or "" for page in reader.pages)
        if not text.strip(): raise ValueError("The PDF contains no extractable text.")
        return {"filename": name, "type": "PDF", "pages": len(reader.pages), "text": text}
    if suffix == "docx":
        document = Document(BytesIO(content)); text = "\n".join(p.text for p in document.paragraphs)
        if not text.strip(): raise ValueError("The DOCX contains no readable text.")
        return {"filename": name, "type": "DOCX", "pages": 0, "text": text}
    raise ValueError("Unsupported file type.")
