"""Citation formatting from collected metadata only."""
def citation(source: dict, style: str = "APA") -> str:
    author = source.get("authors") or "Unknown author"
    year = source.get("year") or "n.d."
    title = source.get("title") or "Untitled"
    url = source.get("url") or ""
    if style == "MLA": return f"{author}. \"{title}.\" {year}. {url}".strip()
    if style == "IEEE": return f"{author}, \"{title},\" {year}. [Online]. Available: {url}".strip()
    return f"{author}. ({year}). {title}. {url}".strip()

def citations(sources: list[dict], style: str) -> list[str]:
    return [citation(s, style) for s in sources if s.get("title")]
