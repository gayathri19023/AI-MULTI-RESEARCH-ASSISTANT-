"""Generate complete PDF and DOCX reports from a workflow result."""
from datetime import date
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.lib.units import cm
from docx import Document
from docx.shared import Inches, Pt

SECTIONS = ["Abstract", "Introduction", "Research Objectives", "Research Questions", "Methodology", "Literature Review", "Key Findings", "Data Analysis", "Source Comparison", "Fact Checking Summary", "Potential Research Gaps", "Discussion", "Conclusion", "Future Scope", "References"]

def report_sections(state: dict) -> dict[str, str]:
    findings = "\n".join(f"- {x}" for x in state.get("findings", [])) or "No sufficiently verified findings were returned."
    claims = "\n".join(f"- {c['claim']}: {c['status']} ({c.get('evidence','')})" for c in state.get("claims", []))
    gaps = "\n".join(f"- Potential research gap: {g['gap']} Future research: {g['future']}" for g in state.get("gaps", []))
    comparison = "\n".join(f"- {x['source']}: {x['finding']} ({x['agreement']})" for x in state.get("comparison", []))
    refs = "\n".join(state.get("citations", []))
    question = state["question"]
    return {"Abstract": state.get("summary", ""), "Introduction": f"This report investigates: {question}", "Research Objectives": "Synthesize available sources, distinguish evidence from interpretation, and identify questions for future study.", "Research Questions": question, "Methodology": state.get("methodology", "Sources were collected through configured providers and analyzed by specialized workflow stages."), "Literature Review": state.get("literature", "No literature synthesis available."), "Key Findings": findings, "Data Analysis": state.get("data_analysis", "No quantitative data were sufficiently structured for analysis."), "Source Comparison": comparison or "No comparison available.", "Fact Checking Summary": claims or "No claims could be verified from available evidence.", "Potential Research Gaps": gaps or "No potential gaps identified.", "Discussion": state.get("discussion", "Interpretations are limited to the collected source set."), "Conclusion": state.get("conclusion", state.get("summary", "")), "Future Scope": "Investigate the potential gaps using a broader, systematically selected evidence base.", "References": refs}

def make_docx(state: dict) -> bytes:
    doc = Document(); sec = doc.sections[0]; sec.top_margin = sec.bottom_margin = Inches(.75)
    title = doc.add_heading(state["topic"], 0); title.style = "Title"
    doc.add_paragraph(f"AI Multi-Agent Research Assistant | Generated {date.today().isoformat()}")
    for heading, content in report_sections(state).items():
        doc.add_heading(heading, level=1)
        for line in content.split("\n"): doc.add_paragraph(line)
    out = BytesIO(); doc.save(out); return out.getvalue()

def make_pdf(state: dict) -> bytes:
    out = BytesIO(); styles = getSampleStyleSheet(); story = [Paragraph(state["topic"], styles["Title"]), Paragraph(f"Generated {date.today().isoformat()}", styles["Normal"]), Spacer(1, .4*cm)]
    for heading, content in report_sections(state).items():
        story += [Paragraph(heading, styles["Heading1"])]
        for line in content.split("\n"): story.append(Paragraph(line.replace("&", "&amp;"), styles["BodyText"]))
        story.append(Spacer(1, .18*cm))
    SimpleDocTemplate(out, pagesize=A4, rightMargin=1.7*cm, leftMargin=1.7*cm, topMargin=1.5*cm, bottomMargin=1.5*cm).build(story)
    return out.getvalue()
