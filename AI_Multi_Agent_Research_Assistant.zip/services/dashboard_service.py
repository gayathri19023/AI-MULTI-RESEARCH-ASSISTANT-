"""Database queries used by the dashboard.

The functions deliberately return safe empty values when the database has not
yet received research data, so a new installation still has a useful page.
"""
from sqlalchemy import func
from sqlalchemy.exc import SQLAlchemyError

from database import get_session, init_db
from database.models import Claim, ResearchGap, ResearchSession, Source


def get_dashboard_data() -> dict:
    """Return dashboard metrics, recent sessions, and daily activity safely."""
    init_db()
    empty = {
        "metrics": {"sessions": 0, "sources": 0, "academic": 0, "claims": 0, "gaps": 0},
        "recent": [],
        "activity": [],
        "error": "",
    }
    try:
        with get_session() as db:
            metrics = {
                "sessions": db.query(func.count(ResearchSession.id)).scalar() or 0,
                "sources": db.query(func.count(Source.id)).scalar() or 0,
                "academic": db.query(func.count(Source.id)).filter(Source.source_type == "academic").scalar() or 0,
                "claims": db.query(func.count(Claim.id)).scalar() or 0,
                "gaps": db.query(func.count(ResearchGap.id)).scalar() or 0,
            }
            recent = [
                {
                    "ID": row.id,
                    "Topic": row.topic,
                    "Question": row.question,
                    "Status": row.status.title(),
                    "Created": row.created_at.strftime("%Y-%m-%d %H:%M"),
                }
                for row in db.query(ResearchSession).order_by(ResearchSession.created_at.desc()).limit(5).all()
            ]
            activity = [
                {"Date": str(day), "Research Sessions": count}
                for day, count in (
                    db.query(func.date(ResearchSession.created_at), func.count(ResearchSession.id))
                    .group_by(func.date(ResearchSession.created_at))
                    .order_by(func.date(ResearchSession.created_at))
                    .all()
                )
            ]
            return {"metrics": metrics, "recent": recent, "activity": activity, "error": ""}
    except SQLAlchemyError as exc:
        empty["error"] = f"Dashboard data is temporarily unavailable: {exc.__class__.__name__}."
        return empty
