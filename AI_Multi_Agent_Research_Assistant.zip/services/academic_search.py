"""Semantic Scholar public API integration."""
import requests
from services.demo_data import DEMO_SOURCES

def search_academic(query: str, limit: int = 5, demo: bool = False) -> list[dict]:
    if demo: return [dict(s) for s in DEMO_SOURCES if s["type"] == "academic"][:limit]
    try:
        r = requests.get("https://api.semanticscholar.org/graph/v1/paper/search", params={"query": query, "limit": limit, "fields": "title,authors,year,abstract,url,venue"}, timeout=15)
        r.raise_for_status()
        return [{"title": p.get("title") or "Untitled", "url": p.get("url") or "", "type": "academic", "year": p.get("year") or "", "authors": ", ".join(a.get("name", "") for a in p.get("authors", [])), "abstract": p.get("abstract") or "", "venue": p.get("venue") or ""} for p in r.json().get("data", [])]
    except requests.RequestException as exc:
        return [{"error": f"Academic search unavailable: {exc}"}]
