"""Web search provider abstraction. Demo data is never represented as live research."""
from urllib.parse import quote_plus
import requests
from services.demo_data import DEMO_SOURCES

def search_web(query: str, limit: int = 5, demo: bool = False) -> list[dict]:
    if demo: return [dict(s) for s in DEMO_SOURCES if s["type"] == "web"][:limit]
    try:
        response = requests.get("https://api.duckduckgo.com/", params={"q": query, "format": "json", "no_html": 1}, timeout=12)
        response.raise_for_status(); data = response.json()
        results = []
        for item in data.get("RelatedTopics", []):
            if isinstance(item, dict) and item.get("FirstURL") and item.get("Text"):
                results.append({"title": item["Text"].split(" - ")[0], "url": item["FirstURL"], "snippet": item["Text"], "type": "web", "year": "", "authors": ""})
            if len(results) >= limit: break
        return results
    except requests.RequestException as exc:
        return [{"error": f"Web search unavailable: {exc}"}]
