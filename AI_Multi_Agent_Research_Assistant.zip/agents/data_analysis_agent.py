import re
import pandas as pd
def data_analysis(state: dict) -> dict:
    text = " ".join(s.get("abstract", s.get("snippet", "")) for s in state.get("sources", []))
    numbers = [float(x) for x in re.findall(r"\b\d+(?:\.\d+)?\b", text)][:50]
    result = "No quantitative data were sufficiently structured for statistical analysis."
    if numbers:
        series = pd.Series(numbers); result = f"Extracted numeric mentions (not a validated dataset): n={len(series)}, mean={series.mean():.2f}, min={series.min():.2f}, max={series.max():.2f}."
    return {"data_analysis": result, "agent_results": {**state.get("agent_results", {}), "Data Analysis": result}}
