from services.citation_service import citations
def citation_agent(state: dict) -> dict:
    items=citations(state.get("sources", []), state.get("citation_style", "APA"))
    return {"citations": items, "agent_results": {**state.get("agent_results", {}), "Citation Generation": f"Generated {len(items)} citations from collected metadata."}}
