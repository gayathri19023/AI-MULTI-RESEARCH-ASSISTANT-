from services.academic_search import search_academic
def academic_research(state: dict) -> dict:
    results = search_academic(state["question"], state.get("source_limit", 5), state.get("demo", False))
    clean = [x for x in results if not x.get("error")]
    notice = next((x["error"] for x in results if x.get("error")), "")
    return {"sources": state.get("sources", []) + clean, "warnings": state.get("warnings", []) + ([notice] if notice else []), "agent_results": {**state.get("agent_results", {}), "Academic Research": f"Collected {len(clean)} academic sources."}}
