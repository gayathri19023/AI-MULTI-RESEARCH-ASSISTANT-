from utils.helpers import compact
def research_manager(state: dict) -> dict:
    topic = state["question"].strip().rstrip("?")
    return {"topic": topic[:180], "tasks": ["web research", "academic research", "document analysis", "comparison", "fact checking", "gap analysis", "report writing"], "agent_results": {**state.get("agent_results", {}), "Research Manager": "Question decomposed into evidence collection and analysis tasks."}}
