from utils.helpers import compact
def document_analysis(state: dict) -> dict:
    docs = state.get("documents", [])
    entries = [{"filename": d["filename"], "summary": compact(d["text"], 450), "key_findings": [compact(d["text"], 180)], "methodology": "Not sufficiently verified from the available document text.", "limitations": "Automated extraction may omit formatting and images."} for d in docs]
    return {"document_results": entries, "agent_results": {**state.get("agent_results", {}), "Document Analysis": f"Analyzed {len(docs)} uploaded documents."}}
