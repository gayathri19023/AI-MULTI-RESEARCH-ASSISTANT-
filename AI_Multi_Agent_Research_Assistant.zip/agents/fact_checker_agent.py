def fact_check(state: dict) -> dict:
    claims=[]
    for s in state.get("sources", [])[:5]:
        evidence = (s.get("abstract") or s.get("snippet") or "").strip()
        if evidence: claims.append({"claim": evidence[:220], "status": "Partially Supported", "evidence": f"Source summary from {s.get('title','Untitled')}", "sources": [s.get("url", "")]})
    return {"claims": claims, "agent_results": {**state.get("agent_results", {}), "Fact Checking": f"Checked {len(claims)} source-derived claims; full-text validation was not performed."}}
