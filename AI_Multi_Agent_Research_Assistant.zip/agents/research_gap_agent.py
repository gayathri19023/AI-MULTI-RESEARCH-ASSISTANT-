def research_gaps(state: dict) -> dict:
    sources=state.get("sources", [])
    gaps=[]
    if sources: gaps.append({"gap":"The collected source set may not represent all regions, populations, methods, or long-term outcomes.", "future":"Conduct a systematic study comparing underrepresented contexts using full-text evidence."})
    return {"gaps": gaps, "agent_results": {**state.get("agent_results", {}), "Research Gap Detection": f"Identified {len(gaps)} potential gaps based on the collected dataset."}}
