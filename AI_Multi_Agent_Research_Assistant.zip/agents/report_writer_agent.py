from services.report_generator import report_sections
def report_writer(state: dict) -> dict:
    summary = f"This report addresses {state['question']} using {len(state.get('sources', []))} collected sources and {len(state.get('documents', []))} uploaded documents. Findings and gaps are limited to this evidence set."
    merged={**state, "summary": summary}
    sections=report_sections(merged)
    report="\n\n".join(f"{name}\n{content}" for name, content in sections.items())
    return {"summary": summary, "report": report, "agent_results": {**state.get("agent_results", {}), "Report Generation": "Structured report drafted from collected evidence."}}
