def compare_sources(state: dict) -> dict:
    rows=[]
    for s in state.get("sources", []):
        rows.append({"source": s.get("title", "Untitled"), "year": s.get("year", ""), "type": s.get("type", ""), "finding": (s.get("abstract") or s.get("snippet") or "No abstract available.")[:220], "method": "Not sufficiently verified from metadata.", "limitations": "Metadata-level comparison.", "agreement": "Requires full-text review to establish agreement or conflict."})
    return {"comparison": rows, "agent_results": {**state.get("agent_results", {}), "Source Comparison": f"Compared {len(rows)} collected sources at metadata/abstract level."}}
