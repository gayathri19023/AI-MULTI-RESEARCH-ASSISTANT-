import re
from pathlib import Path
def safe_filename(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", Path(name).name)
def compact(text: str, limit: int = 500) -> str:
    return " ".join(text.split())[:limit]
