from pathlib import Path
from config import MAX_UPLOAD_BYTES

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt"}
def validate_upload(name: str, size: int) -> str | None:
    if Path(name).suffix.lower() not in ALLOWED_EXTENSIONS: return "Only PDF, DOCX, and TXT files are supported."
    if size > MAX_UPLOAD_BYTES: return f"File exceeds the {MAX_UPLOAD_BYTES // 1024 // 1024} MB limit."
    return None
