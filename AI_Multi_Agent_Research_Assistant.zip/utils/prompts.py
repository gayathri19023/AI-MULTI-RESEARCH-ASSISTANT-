SYSTEM_GUARDRAILS = "Use only collected source metadata and evidence. Mark uncertainty clearly; do not invent citations or facts."
